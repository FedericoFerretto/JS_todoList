
let bottone = document.getElementById("bottone");


bottone.addEventListener("click", function () {
    let aggiunta = document.getElementById("aggiunta").value;
    let lista = document.getElementById("lista");

    var li = document.createElement("li");
    li.innerHTML = aggiunta;
    lista.append(li);


    li.addEventListener("click", function () {
        li.remove();
        rimuoviElementodaDb(li)

    })

    salvaDatiNelDb(aggiunta);


})



let pulizia = document.getElementById("bottone");

pulizia.addEventListener("click", function () {
    document.getElementById("aggiunta").value = '';
})





function salvaDatiNelDb(aggiunta) {

    var ls = localStorage.getItem('elementiSalvati')

    var db = ls ? JSON.parse(ls) : []
    db.push(aggiunta)

    localStorage.setItem('elementiSalvati', JSON.stringify(db))
}


function rimuoviElementodaDb(el) {

    let ls = localStorage.getItem('elementiSalvati')
    let db = JSON.parse(ls)

    let indiceElemento = db.indexOf(el.innerHTML)

    db.splice(indiceElemento, 1)

    localStorage.setItem('elementiSalvati', JSON.stringify(db))
}